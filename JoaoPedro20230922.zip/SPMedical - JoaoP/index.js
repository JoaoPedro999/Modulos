
var http = require('http');
var H = require('./homemodulo');
var CC = require('./ccmodulo');
var CF = require('./cfmodulo');
var L = require('./loginmodulo');
var C = require('./consultasmodulo');


http.createServer (function (req,res) {

res.writeHead(200, {'Content-Type': 'text/html'});

res.write(H.homepage() + "\n" + CC.CadastroCliente() + "\n" + CF.CadastroFuncionario()+ "\n" + L.Login()+ "\n" + C.Consulta());

res.end();
}).listen(5020)


