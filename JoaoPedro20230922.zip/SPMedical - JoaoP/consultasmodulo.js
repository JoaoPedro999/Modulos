exports.Consulta = function () {

return ("<h2>Consultas</h2>");


}
