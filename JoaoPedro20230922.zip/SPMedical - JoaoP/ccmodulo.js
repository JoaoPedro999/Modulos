exports.CadastroCliente = function () {

return ("<h2>Cadastro Cliente</h2>");


}
