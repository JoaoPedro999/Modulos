exports.CadastroFuncionario = function () {

return ("<h2>Cadastro Funcionarios</h2>");


}
